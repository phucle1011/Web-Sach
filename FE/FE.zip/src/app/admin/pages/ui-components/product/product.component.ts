import { Component, OnInit } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ProductService } from 'src/app/services/apis/product.service';


export interface Book {
  productId: number;
  title: string;
  author: string;
  price: number;
  images: string;
}

@Component({
  selector: 'app-product',
  standalone: true,
  imports: [MatCardModule, CommonModule, RouterModule],
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss'],
})
export class AppProductComponent implements OnInit {
  dataSource: Book[] = [];

  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.productService.getAllProducts().subscribe({
      next: (res) => {
        this.dataSource = res.data; // backend đang trả về { status, message, data }
      },
      error: (err) => {
        console.error('Lỗi khi lấy sản phẩm:', err);
      },
    });
  }
}
