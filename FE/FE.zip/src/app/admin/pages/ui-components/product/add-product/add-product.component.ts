import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { ProductService } from 'src/app/services/apis/product.service';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { CategoryService } from 'src/app/services/apis/category.service';
import { HttpClient } from '@angular/common/http';
import { Category } from 'src/app/interface/category.interface';
import { API_ENDPOINT } from 'src/app/config/api-endpoint.config';

@Component({
  selector: 'app-add-product',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule,
    MatTableModule,
    MatCardModule,
    MatIconModule,
    MatButtonModule,
    MatSelectModule,
    FormsModule,
    
  ],
  templateUrl: './add-product.component.html',
  styleUrl: './add-product.component.scss',
})
export class AddProductComponent implements OnInit {
  productForm!: FormGroup;
  selectedFile!: File;
  categories: Category[] = [];

  constructor(
    private fb: FormBuilder,
    private productService: ProductService,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    this.productForm = this.fb.group({
      title: [''],
      author: [''],
      shortDescription: [''],
      publisher: [''],
      price: [0],
      description: [''],
      publicationDate: [''],
      categoryId: ['']
    });

    this.loadCategories();
  }

  loadCategories() {
    this.http.get<any>(`${API_ENDPOINT.category.base}/list`).subscribe(res => {
      this.categories = res.data;
    });
  }

  onFileChange(event: any) {
    this.selectedFile = event.target.files[0];
  }

  onSubmit() {
    const formData = new FormData();
    const formValue = this.productForm.value;
  
    // Chuyển đổi mọi value về string trừ ảnh
    for (let key in formValue) {
      if (formValue[key] !== null && formValue[key] !== undefined) {
        formData.append(key, formValue[key].toString()); 
      }
    }
  
    if (this.selectedFile) {
      formData.append('images', this.selectedFile); 
    }
  
    this.productService.createProduct(formData).subscribe({
      next: () => alert('Thêm sản phẩm thành công'),
      error: (err) => {
        console.error('Lỗi tạo sản phẩm:', err);
        alert('Lỗi khi thêm sản phẩm');
      }
    });
  }
  
}
