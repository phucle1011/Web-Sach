export interface Category {
    categoryId: number;
    categoryName: string;
    status: number;
  }
  