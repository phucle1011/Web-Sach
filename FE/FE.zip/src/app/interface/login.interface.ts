export interface ILogin {
    email: string;
    password: string;
    token?: string;
}