export interface IAlertMessage {
    status: string;
    message: string;
}