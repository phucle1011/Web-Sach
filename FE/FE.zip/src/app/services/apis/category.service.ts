import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { API_ENDPOINT } from '../../config/api-endpoint.config';
@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  private apiUrl = 'http://localhost:3000/categories'; // API URL của bạn

  constructor(private http: HttpClient) {}

  getAllCategories() {
    return this.http.get<any>(`${API_ENDPOINT.category.base}/list`);
  }
}
